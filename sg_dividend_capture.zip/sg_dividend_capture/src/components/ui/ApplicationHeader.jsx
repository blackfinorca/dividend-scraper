import React, { useState } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const ApplicationHeader = ({ theme = 'light', onThemeToggle }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-100 bg-card border-b border-border">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Brand Section */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
            <Icon 
              name="TrendingUp" 
              size={20} 
              color="white" 
              strokeWidth={2}
            />
          </div>
          <div className="flex flex-col">
            <h1 className="text-lg font-semibold text-foreground leading-tight">
              SG Dividend Capture
            </h1>
            <span className="text-xs text-muted-foreground font-medium">
              Prototype
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          <Button
            variant="ghost"
            size="sm"
            className="text-foreground hover:text-primary hover:bg-muted"
          >
            Analyzer
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-primary hover:bg-muted"
          >
            Portfolio
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-primary hover:bg-muted"
          >
            Watchlist
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-primary hover:bg-muted"
          >
            Reports
          </Button>
          
          {/* More Menu */}
          <div className="relative ml-2">
            <Button
              variant="ghost"
              size="sm"
              iconName="MoreHorizontal"
              iconSize={16}
              className="text-muted-foreground hover:text-primary hover:bg-muted"
            >
              More
            </Button>
          </div>
        </nav>

        {/* Utility Controls */}
        <div className="flex items-center space-x-2">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onThemeToggle}
            className="hover:bg-muted hover-transition"
            aria-label="Toggle theme"
          >
            <Icon 
              name={theme === 'light' ? 'Moon' : 'Sun'} 
              size={18} 
              color="currentColor"
              strokeWidth={2}
            />
          </Button>

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleMobileMenu}
            className="md:hidden hover:bg-muted hover-transition"
            aria-label="Toggle menu"
          >
            <Icon 
              name={mobileMenuOpen ? 'X' : 'Menu'} 
              size={20} 
              color="currentColor"
              strokeWidth={2}
            />
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-card border-t border-border animate-slide-in">
          <nav className="px-6 py-4 space-y-2">
            <Button
              variant="ghost"
              size="sm"
              fullWidth
              className="justify-start text-foreground hover:text-primary hover:bg-muted"
            >
              Analyzer
            </Button>
            <Button
              variant="ghost"
              size="sm"
              fullWidth
              className="justify-start text-muted-foreground hover:text-primary hover:bg-muted"
            >
              Portfolio
            </Button>
            <Button
              variant="ghost"
              size="sm"
              fullWidth
              className="justify-start text-muted-foreground hover:text-primary hover:bg-muted"
            >
              Watchlist
            </Button>
            <Button
              variant="ghost"
              size="sm"
              fullWidth
              className="justify-start text-muted-foreground hover:text-primary hover:bg-muted"
            >
              Reports
            </Button>
            
            <div className="pt-2 mt-2 border-t border-border">
              <Button
                variant="ghost"
                size="sm"
                fullWidth
                className="justify-start text-muted-foreground hover:text-primary hover:bg-muted"
              >
                Settings
              </Button>
              <Button
                variant="ghost"
                size="sm"
                fullWidth
                className="justify-start text-muted-foreground hover:text-primary hover:bg-muted"
              >
                Help
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default ApplicationHeader;