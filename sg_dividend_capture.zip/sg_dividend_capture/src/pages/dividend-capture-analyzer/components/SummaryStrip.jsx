import React from 'react';
import Icon from '../../../components/AppIcon';

const SummaryStrip = ({ 
  rowsLoaded = 0, 
  activePresets = {},
  selectedCount = 0,
  totalPnL = 0,
  totalCost = 0,
  className = "" 
}) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-SG', {
      style: 'currency',
      currency: 'SGD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })?.format(amount);
  };

  const getPresetText = () => {
    const presets = [];
    if (activePresets?.buy !== undefined) {
      presets?.push(`Buy: D${activePresets?.buy >= 0 ? '+' : ''}${activePresets?.buy}`);
    }
    if (activePresets?.sell !== undefined) {
      presets?.push(`Sell: D${activePresets?.sell >= 0 ? '+' : ''}${activePresets?.sell}`);
    }
    return presets?.length > 0 ? presets?.join(', ') : 'No presets active';
  };

  return (
    <div className={`bg-muted/50 border border-border rounded-lg p-4 ${className}`}>
      <div className="flex items-center justify-between">
        {/* Left side - Data summary */}
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <Icon 
              name="Database" 
              size={16} 
              color="var(--color-primary)"
              strokeWidth={2}
            />
            <div className="text-sm">
              <span className="font-medium text-foreground">{rowsLoaded}</span>
              <span className="text-muted-foreground ml-1">
                ex-date{rowsLoaded !== 1 ? 's' : ''} loaded
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Icon 
              name="Target" 
              size={16} 
              color="var(--color-accent)"
              strokeWidth={2}
            />
            <div className="text-sm">
              <span className="font-medium text-foreground">{selectedCount}</span>
              <span className="text-muted-foreground ml-1">
                selection{selectedCount !== 1 ? 's' : ''} made
              </span>
            </div>
          </div>
        </div>

        {/* Right side - Preset info */}
        <div className="flex items-center space-x-2">
          <Icon 
            name="Settings2" 
            size={16} 
            color="var(--color-muted-foreground)"
            strokeWidth={2}
          />
          <div className="text-sm text-muted-foreground">
            <span className="font-medium">Presets:</span>
            <span className="ml-1">{getPresetText()}</span>
          </div>
        </div>
      </div>

      {/* Enhanced P&L and Cost Display */}
      {(totalPnL !== 0 || totalCost !== 0) && (
        <div className="mt-4 pt-4 border-t border-border/50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Total P&L - Enhanced Display */}
            <div className="bg-background/80 border border-border rounded-lg p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-full ${
                  totalPnL >= 0 ? 'bg-success/10' : 'bg-error/10'
                }`}>
                  <Icon 
                    name={totalPnL >= 0 ? "TrendingUp" : "TrendingDown"} 
                    size={20} 
                    color={totalPnL >= 0 ? "var(--color-success)" : "var(--color-error)"}
                    strokeWidth={2.5}
                  />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                    Total P&L
                  </div>
                  <div className={`text-xl font-bold ${
                    totalPnL >= 0 ? 'text-success' : 'text-error'
                  }`}>
                    {formatCurrency(totalPnL)}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-foreground">
                  {totalPnL >= 0 ? 'Profit' : 'Loss'}
                </div>
                <div className={`text-sm font-medium ${
                  totalPnL >= 0 ? 'text-success' : 'text-error'
                }`}>
                  {totalPnL >= 0 ? '+' : ''}{((totalPnL / Math.abs(totalPnL || 1)) * 100)?.toFixed(1)}%
                </div>
              </div>
            </div>

            {/* Total Cost Display */}
            <div className="bg-background/80 border border-border rounded-lg p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-full bg-warning/10">
                  <Icon 
                    name="Calculator" 
                    size={20} 
                    color="var(--color-warning)"
                    strokeWidth={2.5}
                  />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                    Total Cost
                  </div>
                  <div className="text-xl font-bold text-warning">
                    {formatCurrency(totalCost)}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-foreground">
                  Margin + Trade
                </div>
                <div className="text-sm font-medium text-warning">
                  Fees & Interest
                </div>
              </div>
            </div>
          </div>

          {/* P&L Breakdown */}
          {totalPnL !== 0 && (
            <div className="mt-3 p-3 bg-muted/30 rounded-lg">
              <div className="text-xs text-muted-foreground font-medium mb-2">
                P&L Components:
              </div>
              <div className="flex flex-wrap gap-4 text-xs">
                <div className="flex items-center space-x-1">
                  <Icon name="ArrowUpDown" size={12} color="var(--color-primary)" />
                  <span className="text-muted-foreground">Price Difference</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="DollarSign" size={12} color="var(--color-success)" />
                  <span className="text-muted-foreground">Dividend Received</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Minus" size={12} color="var(--color-error)" />
                  <span className="text-muted-foreground">Margin Interest</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Receipt" size={12} color="var(--color-error)" />
                  <span className="text-muted-foreground">Trading Fees</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Additional info row */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
          <div className="flex items-center space-x-1">
            <Icon name="Clock" size={12} />
            <span>Data as of: {new Date()?.toLocaleString('en-SG')}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Zap" size={12} />
            <span>Margin Rate: 6% p.a.</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Calculator" size={12} />
            <span>Open/Close: SGD 4.10 each</span>
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          <span>SGX Trading • Real-time calculations</span>
        </div>
      </div>
    </div>
  );
};

export default SummaryStrip;