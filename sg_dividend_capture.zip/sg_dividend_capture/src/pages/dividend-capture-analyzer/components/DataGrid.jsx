import React, { useState, useEffect, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import { calculateSGXMarginCosts } from '../../../utils/sgxMarginCalculator';


const DataGrid = ({ 
  data = [], 
  marginAmount = 50000,
  onCellSelect,
  selectedCells = {},
  className = "" 
}) => {
  const [hoveredCell, setHoveredCell] = useState(null);

  // Generate date columns from D-10 to D+30
  const dateColumns = useMemo(() => {
    const columns = [];
    for (let i = -10; i <= 30; i++) {
      columns?.push({
        key: `D${i >= 0 ? '+' : ''}${i}`,
        label: `D${i >= 0 ? '+' : ''}${i}`,
        offset: i,
        isExDate: i === 0
      });
    }
    return columns;
  }, []);

  // Calculate P&L for a row using SGX margin formulas
  const calculatePnL = (row, buyOffset, sellOffset) => {
    if (!buyOffset || !sellOffset || buyOffset >= 0 || sellOffset <= 0) {
      return null;
    }

    const buyPrice = row?.prices?.[`D${buyOffset}`];
    const sellPrice = row?.prices?.[`D${sellOffset >= 0 ? '+' : ''}${sellOffset}`];
    const dividendAmount = row?.dividendPerShare || 0;

    if (!buyPrice || !sellPrice) return null;

    const quantity = Math.floor(marginAmount / buyPrice);
    const grossPnL = (sellPrice - buyPrice) * quantity;
    const dividendCash = dividendAmount * quantity;
    
    // Calculate holding period
    const holdingDays = Math.abs(sellOffset - buyOffset);
    
    // Use SGX margin cost calculator for accurate fees and interest
    try {
      const marginCosts = calculateSGXMarginCosts({
        tradeValue: marginAmount,
        marginRatio: 0.5, // 50% margin ratio as commonly used
        holdingDays: holdingDays,
        marginInterestRate: 0.06, // 6% annual as specified
        openFees: 4.10,
        closeFees: 4.10
      });
      
      // Total SGX trading costs
      const totalSGXCosts = marginCosts?.totalCost;
      
      // Net P&L calculation
      const netPnL = grossPnL + dividendCash - totalSGXCosts;
      const netPercentage = (netPnL / marginAmount) * 100;

      return {
        quantity,
        grossPnL,
        dividendCash,
        totalFees: marginCosts?.breakdown?.totalFees, // Open + Close fees
        marginInterest: marginCosts?.financingCost,
        totalSGXCosts,
        netPnL,
        netPercentage,
        buyPrice,
        sellPrice,
        holdingDays,
        // Additional SGX-specific details
        borrowed: marginCosts?.borrowed,
        dailyInterest: marginCosts?.dailyInterest,
        sgxCostBreakdown: marginCosts?.breakdown
      };
    } catch (error) {
      console.error('SGX margin calculation error:', error);
      
      // Fallback to simplified calculation
      const totalFees = 8.20; // Open + Close fees
      const marginInterest = (marginAmount * 0.06 * holdingDays) / 365;
      const netPnL = grossPnL + dividendCash - totalFees - marginInterest;
      const netPercentage = (netPnL / marginAmount) * 100;

      return {
        quantity,
        grossPnL,
        dividendCash,
        totalFees,
        marginInterest,
        totalSGXCosts: totalFees + marginInterest,
        netPnL,
        netPercentage,
        buyPrice,
        sellPrice,
        holdingDays
      };
    }
  };

  // Check if row has favorable pattern (D0 <= D-10 AND D+30 >= D-10)
  const getFavorableIntensity = (row) => {
    const d0Price = row?.prices?.['D0'];
    const dMinus10Price = row?.prices?.['D-10'];
    const dPlus30Price = row?.prices?.['D+30'];
    
    if (!d0Price || !dMinus10Price || !dPlus30Price) return 0;
    
    if (d0Price <= dMinus10Price && dPlus30Price >= dMinus10Price) {
      const intensity = Math.min((dPlus30Price - dMinus10Price) / dMinus10Price, 0.2);
      return Math.max(intensity, 0.05); // Minimum 5% opacity
    }
    
    return 0;
  };

  const handleCellClick = (rowId, columnKey, offset) => {
    if (offset >= 0 && offset !== 0) {
      // Sell date selection (D+1 and above)
      onCellSelect && onCellSelect(rowId, columnKey, 'sell', offset);
    } else if (offset < 0) {
      // Buy date selection (D-1 and below)
      onCellSelect && onCellSelect(rowId, columnKey, 'buy', offset);
    }
  };

  const formatPrice = (price) => {
    if (!price || price === '—') return '—';
    return `$${parseFloat(price)?.toFixed(2)}`;
  };

  const formatCurrency = (amount) => {
    if (!amount && amount !== 0) return '—';
    return new Intl.NumberFormat('en-SG', {
      style: 'currency',
      currency: 'SGD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(amount);
  };

  const formatPercentage = (value) => {
    if (!value && value !== 0) return '—';
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value?.toFixed(2)}%`;
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e?.key === 'Escape') {
        onCellSelect && onCellSelect(null, null, 'clear');
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onCellSelect]);

  if (!data || data?.length === 0) {
    return (
      <div className={`bg-card border border-border rounded-lg ${className}`}>
        <div className="flex flex-col items-center justify-center py-12 px-6">
          <Icon 
            name="BarChart3" 
            size={48} 
            color="var(--color-muted-foreground)"
            strokeWidth={1}
            className="mb-4"
          />
          <h3 className="text-lg font-medium text-foreground mb-2">No Data Available</h3>
          <p className="text-sm text-muted-foreground text-center max-w-md">
            Enter a stock symbol and click "Fetch & Calculate" to analyze dividend capture opportunities.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-card border border-border rounded-lg overflow-hidden ${className}`}>
      {/* Grid Container */}
      <div className="overflow-x-auto">
        <div className="min-w-max">
          {/* Header Row */}
          <div className="sticky top-0 bg-muted border-b border-border z-10">
            <div className="flex">
              {/* Fixed columns */}
              <div className="flex bg-muted">
                <div className="w-24 px-3 py-2 text-xs font-medium text-foreground border-r border-border">
                  Ex-Date
                </div>
                <div className="w-20 px-3 py-2 text-xs font-medium text-foreground border-r border-border">
                  Div/Share
                </div>
                <div className="w-16 px-3 py-2 text-xs font-medium text-foreground border-r border-border">
                  Qty
                </div>
                <div className="w-20 px-3 py-2 text-xs font-medium text-foreground border-r border-border">
                  Net P&L
                </div>
                <div className="w-16 px-3 py-2 text-xs font-medium text-foreground border-r border-border">
                  Net %
                </div>
              </div>
              
              {/* Price columns */}
              <div className="flex">
                {dateColumns?.map((column) => (
                  <div
                    key={column?.key}
                    className={`
                      w-16 px-2 py-2 text-xs font-medium text-center border-r border-border
                      ${column?.isExDate 
                        ? 'bg-muted-foreground/20 text-foreground font-semibold' 
                        : 'text-muted-foreground'
                      }
                    `}
                  >
                    {column?.label}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Data Rows */}
          <div className="max-h-96 overflow-y-auto">
            {data?.map((row, rowIndex) => {
              const favorableIntensity = getFavorableIntensity(row);
              const rowSelections = selectedCells?.[row?.id] || {};
              const buyOffset = rowSelections?.buy?.offset;
              const sellOffset = rowSelections?.sell?.offset;
              const pnlData = calculatePnL(row, buyOffset, sellOffset);
              
              return (
                <div
                  key={row?.id}
                  className={`
                    flex border-b border-border hover:bg-accent/50 transition-colors
                    ${favorableIntensity > 0 
                      ? `bg-success/10` 
                      : rowIndex % 2 === 0 ? 'bg-background' : 'bg-muted/30'
                    }
                  `}
                  style={{
                    backgroundColor: favorableIntensity > 0 
                      ? `rgba(5, 150, 105, ${favorableIntensity})` 
                      : undefined
                  }}
                >
                  {/* Fixed columns */}
                  <div className="flex bg-card/80 backdrop-blur-sm">
                    <div className="w-24 px-3 py-2 text-xs font-data text-foreground border-r border-border">
                      {new Date(row.exDate)?.toLocaleDateString('en-GB')}
                    </div>
                    <div className="w-20 px-3 py-2 text-xs font-data text-foreground border-r border-border">
                      ${row?.dividendPerShare?.toFixed(3) || '—'}
                    </div>
                    <div className="w-16 px-3 py-2 text-xs font-data text-foreground border-r border-border">
                      {pnlData?.quantity || '—'}
                    </div>
                    <div className={`
                      w-20 px-3 py-2 text-xs font-data border-r border-border font-medium
                      ${pnlData?.netPnL > 0 ? 'text-success' : pnlData?.netPnL < 0 ? 'text-error' : 'text-foreground'}
                    `}>
                      {pnlData ? formatCurrency(pnlData?.netPnL) : '—'}
                    </div>
                    <div className={`
                      w-16 px-3 py-2 text-xs font-data border-r border-border font-medium
                      ${pnlData?.netPercentage > 0 ? 'text-success' : pnlData?.netPercentage < 0 ? 'text-error' : 'text-foreground'}
                    `}>
                      {pnlData ? formatPercentage(pnlData?.netPercentage) : '—'}
                    </div>
                  </div>
                  {/* Price columns */}
                  <div className="flex">
                    {dateColumns?.map((column) => {
                      const price = row?.prices?.[column?.key];
                      const isSelected = rowSelections?.buy?.columnKey === column?.key || 
                                       rowSelections?.sell?.columnKey === column?.key;
                      const canSelect = (column?.offset < 0) || (column?.offset > 0);
                      const isHovered = hoveredCell === `${row?.id}-${column?.key}`;
                      
                      return (
                        <div
                          key={column?.key}
                          className={`
                            w-16 px-2 py-2 text-xs font-data text-center border-r border-border
                            relative cursor-pointer transition-all duration-150
                            ${column?.isExDate ? 'bg-muted-foreground/10' : ''}
                            ${canSelect ? 'hover:bg-accent hover:text-accent-foreground' : 'cursor-not-allowed'}
                            ${isSelected ? 'bg-primary/20 ring-1 ring-primary' : ''}
                            ${isHovered && canSelect ? 'bg-accent/50' : ''}
                          `}
                          onClick={() => canSelect && handleCellClick(row?.id, column?.key, column?.offset)}
                          onMouseEnter={() => setHoveredCell(`${row?.id}-${column?.key}`)}
                          onMouseLeave={() => setHoveredCell(null)}
                          title={canSelect ? `Click to select ${column?.offset < 0 ? 'buy' : 'sell'} date` : 'Cannot select ex-date'}
                        >
                          {formatPrice(price)}
                          {/* Selection badges */}
                          {isSelected && (
                            <div className={`
                              absolute -top-1 -right-1 w-4 h-4 rounded-full text-[8px] font-bold
                              flex items-center justify-center text-white
                              ${rowSelections?.buy?.columnKey === column?.key ? 'bg-blue-500' : 'bg-red-500'}
                            `}>
                              {rowSelections?.buy?.columnKey === column?.key ? 'B' : 'S'}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      {/* Instructions */}
      <div className="px-4 py-3 bg-muted/50 border-t border-border">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span>Buy Date</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span>Sell Date</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-success/30 rounded"></div>
              <span>Favorable Pattern</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Info" size={12} />
            <span>Press ESC to clear selections • Click cells to select buy/sell dates</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataGrid;