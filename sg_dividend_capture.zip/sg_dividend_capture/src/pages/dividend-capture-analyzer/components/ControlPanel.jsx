import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';
import TickerAutocomplete from './TickerAutocomplete';

const ControlPanel = ({ 
  onFetchData, 
  onReset, 
  loading = false,
  onPresetApply,
  className = "" 
}) => {
  const [formData, setFormData] = useState({
    ticker: '',
    marginAmount: '50000',
    startDate: '2019-10-10',
    endDate: '2024-10-10'
  });

  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData?.ticker) {
      newErrors.ticker = 'Stock symbol is required';
    }
    
    if (!formData?.marginAmount || parseFloat(formData?.marginAmount) < 0) {
      newErrors.marginAmount = 'Margin amount must be ≥ 0';
    }
    
    if (!formData?.startDate) {
      newErrors.startDate = 'Start date is required';
    }
    
    if (!formData?.endDate) {
      newErrors.endDate = 'End date is required';
    }
    
    if (formData?.startDate && formData?.endDate && new Date(formData.startDate) >= new Date(formData.endDate)) {
      newErrors.endDate = 'End date must be after start date';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (validateForm() && onFetchData) {
      onFetchData(formData);
    }
  };

  const handleReset = () => {
    setFormData({
      ticker: '',
      marginAmount: '50000',
      startDate: '2019-10-10',
      endDate: '2024-10-10'
    });
    setErrors({});
    if (onReset) {
      onReset();
    }
  };

  const buyPresets = [
    { label: 'D-1', value: -1, description: 'Buy 1 day before ex-date' },
    { label: 'D-3', value: -3, description: 'Buy 3 days before ex-date' },
    { label: 'D-5', value: -5, description: 'Buy 5 days before ex-date' }
  ];

  const sellPresets = [
    { label: 'D+5', value: 5, description: 'Sell 5 days after ex-date' },
    { label: 'D+10', value: 10, description: 'Sell 10 days after ex-date' },
    { label: 'D+30', value: 30, description: 'Sell 30 days after ex-date' }
  ];

  return (
    <div className={`bg-card border border-border rounded-lg shadow-minimal ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon 
            name="Settings" 
            size={18} 
            color="var(--color-primary)"
            strokeWidth={2}
          />
          <h2 className="text-sm font-semibold text-foreground">
            Analysis Parameters
          </h2>
        </div>
        <div className="text-xs text-muted-foreground">
          Last updated: {new Date()?.toLocaleTimeString()}
        </div>
      </div>
      {/* Form Content */}
      <form onSubmit={handleSubmit} className="p-4">
        {/* Primary Inputs Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <TickerAutocomplete
            value={formData?.ticker}
            onChange={(value) => handleInputChange('ticker', value)}
            error={errors?.ticker}
            disabled={loading}
          />

          <Input
            label="Margin Amount (SGD)"
            type="number"
            placeholder="50000"
            value={formData?.marginAmount}
            onChange={(e) => handleInputChange('marginAmount', e?.target?.value)}
            error={errors?.marginAmount}
            disabled={loading}
            min="0"
            step="1000"
            required
          />

          <Input
            label="Start Date"
            type="date"
            value={formData?.startDate}
            onChange={(e) => handleInputChange('startDate', e?.target?.value)}
            error={errors?.startDate}
            disabled={loading}
            required
          />

          <Input
            label="End Date"
            type="date"
            value={formData?.endDate}
            onChange={(e) => handleInputChange('endDate', e?.target?.value)}
            error={errors?.endDate}
            disabled={loading}
            required
          />
        </div>

        {/* Preset Buttons */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Buy Presets */}
          <div>
            <h3 className="text-sm font-medium text-foreground mb-2">Buy Presets</h3>
            <div className="flex flex-wrap gap-2">
              {buyPresets?.map((preset) => (
                <Button
                  key={preset?.value}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => onPresetApply && onPresetApply('buy', preset?.value)}
                  disabled={loading}
                  className="text-xs"
                  title={preset?.description}
                >
                  {preset?.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Sell Presets */}
          <div>
            <h3 className="text-sm font-medium text-foreground mb-2">Sell Presets</h3>
            <div className="flex flex-wrap gap-2">
              {sellPresets?.map((preset) => (
                <Button
                  key={preset?.value}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => onPresetApply && onPresetApply('sell', preset?.value)}
                  disabled={loading}
                  className="text-xs"
                  title={preset?.description}
                >
                  {preset?.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="flex items-center space-x-3">
            <Button
              type="submit"
              variant="default"
              loading={loading}
              iconName="Play"
              iconPosition="left"
              iconSize={16}
              disabled={!formData?.ticker || !formData?.marginAmount}
            >
              Fetch & Calculate
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleReset}
              iconName="RotateCcw"
              iconPosition="left"
              iconSize={16}
              disabled={loading}
            >
              Reset
            </Button>
          </div>

          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
            <Icon 
              name="Info" 
              size={14} 
              color="currentColor"
              strokeWidth={2}
            />
            <span>SGX Trading Hours: 9:00 AM - 5:00 PM SGT</span>
          </div>
        </div>
      </form>
    </div>
  );
};

export default ControlPanel;