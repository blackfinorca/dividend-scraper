import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const TickerAutocomplete = ({ value, onChange, error, disabled = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState(value || '');
  const inputRef = useRef(null);
  const dropdownRef = useRef(null);

  // Top 50 Singapore stocks by market cap (SGX listed) + Singapore REITs and Business Trusts
  const sgStocks = [
    { symbol: 'D05.SI', name: 'DBS Group Holdings Ltd', sector: 'Financials', marketCap: '~S$90B' },
    { symbol: 'O39.SI', name: 'Oversea-Chinese Banking Corporation Limited', sector: 'Financials', marketCap: '~S$60B' },
    { symbol: 'U11.SI', name: 'United Overseas Bank Limited', sector: 'Financials', marketCap: '~S$45B' },
    { symbol: 'Z74.SI', name: 'Singapore Telecommunications Limited', sector: 'Communication Services', marketCap: '~S$40B' },
    { symbol: 'C6L.SI', name: 'Singapore Airlines Limited', sector: 'Industrials', marketCap: '~S$20B' },
    { symbol: 'S68.SI', name: 'Singapore Exchange Limited', sector: 'Financials', marketCap: '~S$18B' },
    { symbol: 'G13.SI', name: 'Genting Singapore Limited', sector: 'Consumer Discretionary', marketCap: '~S$15B' },
    { symbol: 'Y92.SI', name: 'Thai Beverage Public Company Limited', sector: 'Consumer Staples', marketCap: '~S$14B' },
    { symbol: 'V03.SI', name: 'Venture Corporation Limited', sector: 'Technology', marketCap: '~S$12B' },
    { symbol: 'H78.SI', name: 'Hongkong Land Holdings Limited', sector: 'Real Estate', marketCap: '~S$11B' },
    { symbol: 'J36.SI', name: 'Jardine Matheson Holdings Limited', sector: 'Industrials', marketCap: '~S$11B' },
    { symbol: 'C52.SI', name: 'ComfortDelGro Corporation Limited', sector: 'Industrials', marketCap: '~S$10B' },
    { symbol: 'C38U.SI', name: 'CapitaLand Integrated Commercial Trust', sector: 'Real Estate', marketCap: '~S$10B' },
    { symbol: 'A17U.SI', name: 'CapitaLand Ascendas REIT', sector: 'Real Estate', marketCap: '~S$9B' },
    { symbol: 'J37.SI', name: 'Jardine Strategic Holdings Limited', sector: 'Industrials', marketCap: '~S$8B' },
    { symbol: 'C07.SI', name: 'Jardine Cycle & Carriage Limited', sector: 'Consumer Discretionary', marketCap: '~S$7B' },
    { symbol: 'F34.SI', name: 'Wilmar International Limited', sector: 'Consumer Staples', marketCap: '~S$7B' },
    { symbol: 'N2IU.SI', name: 'Mapletree Pan Asia Commercial Trust', sector: 'Real Estate', marketCap: '~S$6B' },
    { symbol: 'M44U.SI', name: 'Mapletree Logistics Trust', sector: 'Real Estate', marketCap: '~S$6B' },
    { symbol: 'BN4.SI', name: 'Keppel REIT', sector: 'Real Estate', marketCap: '~S$5B' },
    { symbol: 'ES3.SI', name: 'Keppel Corporation Limited', sector: 'Industrials', marketCap: '~S$5B' },
    { symbol: 'C31.SI', name: 'CapitaLand Investment Limited', sector: 'Real Estate', marketCap: '~S$5B' },
    { symbol: 'C09.SI', name: 'City Developments Limited', sector: 'Real Estate', marketCap: '~S$4B' },
    { symbol: 'G07.SI', name: 'Great Eastern Holdings Limited', sector: 'Financials', marketCap: '~S$4B' },
    { symbol: 'U96.SI', name: 'Sembcorp Industries Ltd', sector: 'Utilities', marketCap: '~S$4B' },
    { symbol: 'S63.SI', name: 'Singapore Technologies Engineering Ltd', sector: 'Industrials', marketCap: '~S$4B' },
    { symbol: 'H13.SI', name: 'Hutchison Port Holdings Trust', sector: 'Industrials', marketCap: '~S$3B' },
    { symbol: 'S58.SI', name: 'SATS Ltd.', sector: 'Industrials', marketCap: '~S$3B' },
    { symbol: 'ME8U.SI', name: 'Mapletree Industrial Trust', sector: 'Real Estate', marketCap: '~S$3B' },
    { symbol: 'T82U.SI', name: 'Suntec REIT', sector: 'Real Estate', marketCap: '~S$3B' },
    { symbol: 'S51.SI', name: 'Sembcorp Marine Ltd', sector: 'Industrials', marketCap: '~S$2.5B' },
    { symbol: 'UOL.SI', name: 'UOL Group Limited', sector: 'Real Estate', marketCap: '~S$2.5B' },
    { symbol: 'S08.SI', name: 'Singapore Post Limited', sector: 'Industrials', marketCap: '~S$2B' },
    { symbol: 'K71U.SI', name: 'Keppel REIT', sector: 'Real Estate', marketCap: '~S$2B' },
    { symbol: 'J85.SI', name: 'Jardine Matheson International Services (S) Pte Ltd', sector: 'Industrials', marketCap: '~S$2B' },
    { symbol: 'F99.SI', name: 'Food Empire Holdings Limited', sector: 'Consumer Staples', marketCap: '~S$1.8B' },
    { symbol: 'P40U.SI', name: 'Starhill Global REIT', sector: 'Real Estate', marketCap: '~S$1.8B' },
    { symbol: 'RW0U.SI', name: 'Mapletree North Asia Commercial Trust', sector: 'Real Estate', marketCap: '~S$1.7B' },
    { symbol: 'SGX.SI', name: 'Singapore Exchange Limited', sector: 'Financials', marketCap: '~S$1.7B' },
    { symbol: 'L38U.SI', name: 'Lendlease Global Commercial REIT', sector: 'Real Estate', marketCap: '~S$1.5B' },
    { symbol: 'N32.SI', name: 'Keppel Pacific Oak US REIT', sector: 'Real Estate', marketCap: '~S$1.5B' },
    { symbol: 'AWX.SI', name: 'AEM Holdings Ltd', sector: 'Technology', marketCap: '~S$1.4B' },
    { symbol: 'A68U.SI', name: 'Ascendas India Trust', sector: 'Real Estate', marketCap: '~S$1.4B' },
    { symbol: 'E5H.SI', name: 'Golden Agri-Resources Ltd', sector: 'Consumer Staples', marketCap: '~S$1.3B' },
    { symbol: 'CC3.SI', name: 'StarHub Ltd', sector: 'Communication Services', marketCap: '~S$1.3B' },
    { symbol: 'SV3U.SI', name: 'SPH REIT', sector: 'Real Estate', marketCap: '~S$1.2B' },
    { symbol: 'BSL.SI', name: 'Biosensors International Group, Ltd.', sector: 'Healthcare', marketCap: '~S$1.2B' },
    { symbol: 'C2PU.SI', name: 'CapitaLand Ascott Trust', sector: 'Real Estate', marketCap: '~S$1.1B' },
    { symbol: 'S61.SI', name: 'SembCorp Marine Ltd', sector: 'Industrials', marketCap: '~S$1.1B' },
    { symbol: 'G92.SI', name: 'First Resources Limited', sector: 'Consumer Staples', marketCap: '~S$1B' },
    
    // Singapore REITs and Business Trusts
    { symbol: 'O5RU.SI', name: 'AIMS APAC REIT', sector: 'Real Estate', marketCap: '~S$800M' },
    { symbol: 'HMN.SI', name: 'CapitaLand Ascott Trust', sector: 'Real Estate', marketCap: '~S$1.1B' },
    { symbol: '9CI.SI', name: 'CapitaLand Investment', sector: 'Real Estate', marketCap: '~S$5B' },
    { symbol: 'CRPU.SI', name: 'Sasseur REIT', sector: 'Real Estate', marketCap: '~S$400M' },
    { symbol: 'C2PU.SI', name: 'Parkway Life REIT', sector: 'Real Estate', marketCap: '~S$1.8B' },
    { symbol: 'AJBU.SI', name: 'Keppel DC REIT', sector: 'Real Estate', marketCap: '~S$2B' },
    { symbol: 'CMOU.SI', name: 'Keppel Pacific Oak US REIT', sector: 'Real Estate', marketCap: '~S$1.5B' },
    { symbol: 'J91U.SI', name: 'ESR-LOGOS REIT', sector: 'Real Estate', marketCap: '~S$1.2B' },
    { symbol: 'DCRU.SI', name: 'Digital Core REIT', sector: 'Real Estate', marketCap: '~S$600M' },
    { symbol: 'MXNU.SI', name: 'Elite Commercial REIT', sector: 'Real Estate', marketCap: '~S$300M' },
    { symbol: 'UD1U.SI', name: 'IREIT Global', sector: 'Real Estate', marketCap: '~S$250M' },
    { symbol: 'JYEU.SI', name: 'Lendlease Global Commercial REIT', sector: 'Real Estate', marketCap: '~S$1.5B' },
    { symbol: 'D5IU.SI', name: 'Lippo Malls Indonesia Retail Trust', sector: 'Real Estate', marketCap: '~S$200M' },
    { symbol: 'BTOU.SI', name: 'Manulife US REIT', sector: 'Real Estate', marketCap: '~S$450M' },
    { symbol: 'TS0U.SI', name: 'OUE Commercial REIT', sector: 'Real Estate', marketCap: '~S$600M' },
    { symbol: 'OXMU.SI', name: 'Prime US REIT', sector: 'Real Estate', marketCap: '~S$300M' },
    { symbol: 'M1GU.SI', name: 'Sabana Industrial REIT', sector: 'Real Estate', marketCap: '~S$250M' },
    { symbol: 'C83U.SI', name: 'Cromwell European REIT', sector: 'Real Estate', marketCap: '~S$400M' },
    { symbol: 'DHLU.SI', name: 'Daiwa House Logistics Trust', sector: 'Real Estate', marketCap: '~S$500M' },
    { symbol: 'ODBU.SI', name: 'United Hampshire US REIT', sector: 'Real Estate', marketCap: '~S$200M' },
    { symbol: 'BUOU.SI', name: 'Frasers Logistics & Commercial Trust', sector: 'Real Estate', marketCap: '~S$2.5B' },
    { symbol: 'J69U.SI', name: 'Frasers Centrepoint Trust', sector: 'Real Estate', marketCap: '~S$2B' },
    { symbol: 'K2LU.SI', name: 'Keppel Infrastructure Trust', sector: 'Business Trust', marketCap: '~S$1.5B' },
    { symbol: 'CY6U.SI', name: 'CapitaLand India Trust', sector: 'Business Trust', marketCap: '~S$800M' }
  ];

  const filteredStocks = searchTerm
    ? sgStocks?.filter(stock => 
        stock?.symbol?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        stock?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        stock?.sector?.toLowerCase()?.includes(searchTerm?.toLowerCase())
      )?.slice(0, 10)
    : sgStocks?.slice(0, 10);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInputChange = (e) => {
    const newValue = e?.target?.value?.toUpperCase();
    setSearchTerm(newValue);
    onChange(newValue);
    setIsOpen(true);
  };

  const handleStockSelect = (stock) => {
    setSearchTerm(stock?.symbol);
    onChange(stock?.symbol);
    setIsOpen(false);
  };

  const handleKeyDown = (e) => {
    if (e?.key === 'Escape') {
      setIsOpen(false);
    } else if (e?.key === 'ArrowDown' && !isOpen) {
      setIsOpen(true);
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <label className="block text-sm font-medium text-foreground mb-1">
        Stock Symbol
        <span className="text-error ml-1">*</span>
      </label>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={searchTerm}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsOpen(true)}
          placeholder="Search SGX stocks: D05.SI, O39.SI, U11.SI..."
          disabled={disabled}
          className={`
            w-full px-3 py-2 pr-10 text-sm font-data
            bg-input border rounded-md
            transition-colors duration-200
            ${disabled 
              ? 'opacity-50 cursor-not-allowed border-muted' :'hover:border-ring focus:border-ring focus:ring-1 focus:ring-ring'
            }
            ${error ? 'border-error' : 'border-border'}
            focus:outline-none
          `}
        />
        
        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
          <Icon 
            name="Search" 
            size={16} 
            color="var(--color-muted-foreground)"
            strokeWidth={2}
          />
        </div>
      </div>
      
      {isOpen && filteredStocks?.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-80 overflow-y-auto">
          <div className="px-3 py-2 bg-muted border-b border-border">
            <div className="text-xs font-medium text-muted-foreground">
              Top 50 SGX Companies by Market Cap
            </div>
          </div>
          {filteredStocks?.map((stock) => (
            <div
              key={stock?.symbol}
              className="px-3 py-2 cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors border-b border-border/50 last:border-b-0"
              onClick={() => handleStockSelect(stock)}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="font-data text-sm font-semibold text-foreground mb-1">
                    {stock?.symbol}
                  </div>
                  <div className="text-xs text-muted-foreground truncate mb-1">
                    {stock?.name}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {stock?.sector}
                    </span>
                    <span className="text-xs font-medium text-primary">
                      {stock?.marketCap}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {error && (
        <p className="text-xs text-error mt-1 flex items-center">
          <Icon name="AlertCircle" size={12} className="mr-1" />
          {error}
        </p>
      )}
      
      {searchTerm && !filteredStocks?.length && isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg p-3">
          <div className="text-center text-sm text-muted-foreground">
            No matching SGX stocks found
          </div>
        </div>
      )}
    </div>
  );
};

export default TickerAutocomplete;