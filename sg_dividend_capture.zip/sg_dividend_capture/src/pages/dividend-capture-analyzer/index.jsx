import React, { useState, useCallback } from 'react';
import ApplicationHeader from '../../components/ui/ApplicationHeader';
import StatusBanner from '../../components/ui/StatusBanner';
import ControlPanel from './components/ControlPanel';
import SummaryStrip from './components/SummaryStrip';
import DataGrid from './components/DataGrid';
import DisclaimerFooter from './components/DisclaimerFooter';
import { calculateSGXMarginCosts } from '../../utils/sgxMarginCalculator';

const DividendCaptureAnalyzer = () => {
  const [theme, setTheme] = useState('light');
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [statusType, setStatusType] = useState('info');
  const [gridData, setGridData] = useState([]);
  const [selectedCells, setSelectedCells] = useState({});
  const [activePresets, setActivePresets] = useState({});
  const [currentParams, setCurrentParams] = useState(null);

  // Mock dividend data generator
  const generateMockData = (ticker, startDate, endDate) => {
    const mockData = [];
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    // Generate quarterly ex-dates
    const currentDate = new Date(start);
    let id = 1;
    
    while (currentDate <= end) {
      // Generate prices for D-10 to D+30
      const basePrice = 25 + Math.random() * 15; // Base price between $25-40
      const prices = {};
      
      for (let i = -10; i <= 30; i++) {
        const volatility = 0.02 + Math.random() * 0.03; // 2-5% daily volatility
        const trend = i < 0 ? 0.001 : i === 0 ? -0.015 : 0.002; // Slight drop on ex-date
        const randomFactor = (Math.random() - 0.5) * volatility;
        
        let price = basePrice * (1 + trend * Math.abs(i) + randomFactor);
        
        // Simulate missing prices for weekends/holidays (10% chance)
        if (Math.random() < 0.1) {
          prices[`D${i >= 0 ? '+' : ''}${i}`] = null;
        } else {
          prices[`D${i >= 0 ? '+' : ''}${i}`] = price?.toFixed(2);
        }
      }
      
      mockData?.push({
        id: `${ticker}-${id}`,
        exDate: new Date(currentDate)?.toISOString()?.split('T')?.[0],
        dividendPerShare: 0.15 + Math.random() * 0.25, // $0.15-0.40 dividend
        prices
      });
      
      // Move to next quarter
      currentDate?.setMonth(currentDate?.getMonth() + 3);
      id++;
    }
    
    return mockData?.slice(0, 20); // Limit to 20 records for demo
  };

  const handleFetchData = useCallback(async (params) => {
    setLoading(true);
    setStatusMessage('');
    setCurrentParams(params);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Validate ticker format
      if (!params?.ticker?.includes('.SI')) {
        throw new Error('Please use Singapore stock format (e.g., ES3.SI)');
      }
      
      const mockData = generateMockData(params?.ticker, params?.startDate, params?.endDate);
      
      if (mockData?.length === 0) {
        setStatusMessage('No dividend data found for the selected date range');
        setStatusType('warning');
      } else {
        setStatusMessage(`Successfully loaded ${mockData?.length} ex-dividend dates for ${params?.ticker}`);
        setStatusType('success');
      }
      
      setGridData(mockData);
      setSelectedCells({});
      setActivePresets({});
      
    } catch (error) {
      setStatusMessage(error?.message || 'Failed to fetch data. Please check your parameters and try again.');
      setStatusType('error');
      setGridData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleReset = useCallback(() => {
    setGridData([]);
    setSelectedCells({});
    setActivePresets({});
    setStatusMessage('');
    setCurrentParams(null);
  }, []);

  const handlePresetApply = useCallback((type, offset) => {
    if (gridData?.length === 0) {
      setStatusMessage('Please fetch data first before applying presets');
      setStatusType('warning');
      return;
    }

    const newSelectedCells = { ...selectedCells };
    const newActivePresets = { ...activePresets, [type]: offset };
    
    gridData?.forEach(row => {
      if (!newSelectedCells?.[row?.id]) {
        newSelectedCells[row.id] = {};
      }
      
      const columnKey = `D${offset >= 0 ? '+' : ''}${offset}`;
      newSelectedCells[row.id][type] = {
        columnKey,
        offset
      };
    });
    
    setSelectedCells(newSelectedCells);
    setActivePresets(newActivePresets);
    setStatusMessage(`Applied ${type} preset D${offset >= 0 ? '+' : ''}${offset} to all rows`);
    setStatusType('info');
  }, [gridData, selectedCells, activePresets]);

  const handleCellSelect = useCallback((rowId, columnKey, action, offset) => {
    if (action === 'clear') {
      setSelectedCells({});
      setActivePresets({});
      setStatusMessage('All selections cleared');
      setStatusType('info');
      return;
    }

    const newSelectedCells = { ...selectedCells };
    
    if (!newSelectedCells?.[rowId]) {
      newSelectedCells[rowId] = {};
    }
    
    newSelectedCells[rowId][action] = {
      columnKey,
      offset
    };
    
    setSelectedCells(newSelectedCells);
  }, [selectedCells]);

  const handleThemeToggle = useCallback(() => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  }, []);

  const handleStatusDismiss = useCallback(() => {
    setStatusMessage('');
  }, []);

  // Calculate summary statistics
  const selectedCount = Object.keys(selectedCells)?.reduce((count, rowId) => {
    const row = selectedCells?.[rowId];
    return count + (row?.buy ? 1 : 0) + (row?.sell ? 1 : 0);
  }, 0);

  // Calculate total P&L and total costs
  const { totalPnL, totalCost } = Object.keys(selectedCells)?.reduce((totals, rowId) => {
    const row = selectedCells?.[rowId];
    if (row?.buy && row?.sell && currentParams) {
      const dataRow = gridData?.find(d => d?.id === rowId);
      if (dataRow) {
        const buyPrice = parseFloat(dataRow?.prices?.[row?.buy?.columnKey]);
        const sellPrice = parseFloat(dataRow?.prices?.[row?.sell?.columnKey]);
        const dividendAmount = dataRow?.dividendPerShare || 0;
        
        if (buyPrice && sellPrice) {
          const quantity = Math.floor(parseFloat(currentParams?.marginAmount) / buyPrice);
          const holdingDays = Math.abs(row?.sell?.offset - row?.buy?.offset);
          const tradeValue = parseFloat(currentParams?.marginAmount);
          
          // Calculate price difference and dividend cash
          const priceDifference = (sellPrice - buyPrice) * quantity;
          const dividendCash = dividendAmount * quantity;
          
          // Calculate total costs using SGX margin formulas
          const costCalculation = calculateSGXMarginCosts({
            tradeValue: tradeValue,
            marginRatio: 0.5, // 50% margin
            holdingDays: holdingDays
          });
          
          // Net P&L = Price difference + Dividends - Total costs
          const netPnL = priceDifference + dividendCash - costCalculation?.totalCost;
          
          return {
            totalPnL: totals?.totalPnL + netPnL,
            totalCost: totals?.totalCost + costCalculation?.totalCost
          };
        }
      }
    }
    return totals;
  }, { totalPnL: 0, totalCost: 0 });

  return (
    <div className="min-h-screen bg-background">
      <ApplicationHeader 
        theme={theme} 
        onThemeToggle={handleThemeToggle}
      />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-foreground mb-2">
              Dividend Capture Analyzer
            </h1>
            <p className="text-sm text-muted-foreground">
              Analyze historical dividend-capture trading opportunities for Singapore-listed stocks with comprehensive P&L calculations.
            </p>
          </div>

          {/* Status Banner */}
          {statusMessage && (
            <StatusBanner
              message={statusMessage}
              type={statusType}
              onDismiss={handleStatusDismiss}
              autoHide={statusType === 'success'}
              className="mb-6"
            />
          )}

          {/* Control Panel */}
          <ControlPanel
            onFetchData={handleFetchData}
            onReset={handleReset}
            onPresetApply={handlePresetApply}
            loading={loading}
            className="mb-6"
          />

          {/* Summary Strip */}
          {gridData?.length > 0 && (
            <SummaryStrip
              rowsLoaded={gridData?.length}
              activePresets={activePresets}
              selectedCount={selectedCount}
              totalPnL={totalPnL}
              totalCost={totalCost}
              className="mb-6"
            />
          )}

          {/* Data Grid */}
          <DataGrid
            data={gridData}
            marginAmount={currentParams?.marginAmount ? parseFloat(currentParams?.marginAmount) : 50000}
            onCellSelect={handleCellSelect}
            selectedCells={selectedCells}
            className="mb-6"
          />

          {/* Disclaimer Footer */}
          <DisclaimerFooter />
        </div>
      </main>
    </div>
  );
};

export default DividendCaptureAnalyzer;